 const express = require("express");
const mysql = require("mysql2");
const path = require("path");

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// MySQL connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Shaik_Sumaya@09",
    database: "sumaya_bus_registration"
});

db.connect((err) => {
    if (err) {
        console.log("Database connection failed:", err.message);
        return;
    }
    console.log("MySQL connected successfully!");
});

// HOME PAGE
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "index.html"));
});

// INSERT BUS
app.post("/insert", (req, res) => {
    const {
        bus_number, bus_name, source, destination,
        departure_time, arrival_time, total_seats, fare, status
    } = req.body;

    const sql = `INSERT INTO buses
        (bus_number, bus_name, source, destination,
        departure_time, arrival_time, total_seats, fare, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    db.query(sql, [
        bus_number, bus_name, source, destination,
        departure_time, arrival_time, total_seats, fare, status
    ], (err) => {
        if (err) {
            return res.status(400).send(
                "Error inserting bus: " + err.message +
                '<br><a href="/insert.html">Go Back</a>'
            );
        }
        res.redirect("/list.html");
    });
});

// VIEW ALL BUSES
app.get("/list", (req, res) => {
    db.query("SELECT * FROM buses", (err, results) => {
        if (err) return res.status(500).send(err.message);

        let html = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Sumaya - Registered Buses</title>
            <link rel="stylesheet" href="/style.css">
        </head>
        <body>
            <div class="container">
                <h1>Sumaya Bus Registration</h1>
                <h2>Registered Buses</h2>
                <table>
                    <tr>
                        <th>ID</th><th>Bus Number</th><th>Name</th>
                        <th>Source</th><th>Destination</th>
                        <th>Departure</th><th>Arrival</th>
                        <th>Seats</th><th>Fare</th><th>Status</th>
                    </tr>`;

        results.forEach(bus => {
            html += `<tr>
                <td>${bus.bus_id}</td>
                <td>${bus.bus_number}</td>
                <td>${bus.bus_name}</td>
                <td>${bus.source}</td>
                <td>${bus.destination}</td>
                <td>${bus.departure_time}</td>
                <td>${bus.arrival_time}</td>
                <td>${bus.total_seats}</td>
                <td>₹${bus.fare}</td>
                <td>${bus.status}</td>
            </tr>`;
        });

        html += `</table>
                <p><a href="/">Home</a> |
                <a href="/insert.html">Register Another Bus</a></p>
            </div>
        </body>
        </html>`;

        res.send(html);
    });
});

// GET ONE BUS FOR UPDATE
app.get("/bus/:id", (req, res) => {
    db.query(
        "SELECT * FROM buses WHERE bus_id = ?",
        [req.params.id],
        (err, results) => {
            if (err) return res.status(500).send(err.message);
            if (results.length === 0) {
                return res.status(404).send("Bus not found");
            }
            res.json(results[0]);
        }
    );
});

// UPDATE BUS
app.post("/update", (req, res) => {
    const {
        bus_id, bus_number, bus_name, source, destination,
        departure_time, arrival_time, total_seats, fare, status
    } = req.body;

    const sql = `UPDATE buses SET
        bus_number=?, bus_name=?, source=?, destination=?,
        departure_time=?, arrival_time=?, total_seats=?,
        fare=?, status=? WHERE bus_id=?`;

    db.query(sql, [
        bus_number, bus_name, source, destination,
        departure_time, arrival_time, total_seats, fare, status,
        bus_id
    ], (err, result) => {
        if (err) return res.status(400).send(err.message);
        if (result.affectedRows === 0) {
            return res.status(404).send("Bus not found");
        }
        res.redirect("/list.html");
    });
});

// DELETE BUS
app.post("/delete", (req, res) => {
    db.query(
        "DELETE FROM buses WHERE bus_id = ?",
        [req.body.bus_id],
        (err, result) => {
            if (err) return res.status(400).send(err.message);
            if (result.affectedRows === 0) {
                return res.status(404).send("Bus not found");
            }
            res.redirect("/list.html");
        }
    );
});
/* GET ALL BUSES FOR UPDATE AND DELETE DROPDOWNS */
app.get("/buses", (req, res) => {
    db.query(
        "SELECT bus_id, bus_number, bus_name FROM buses ORDER BY bus_id",
        (err, results) => {
            if (err) {
                return res.status(500).json({ error: err.message });
            }
            res.json(results);
        }
    );
});
// START SERVER
app.listen(3000, () => {
    console.log("Sumaya Bus Registration running at http://localhost:3000");
});